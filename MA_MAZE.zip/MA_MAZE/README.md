# MA_MAZE

Agente capaz de generar un laberinto de dimensiones NxM
