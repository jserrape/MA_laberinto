# dilemaPrisionero
Dilema del prisionero: ontología
