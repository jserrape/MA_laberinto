#Este es el proyecto en GIT para las prácticas 2016 de multiagentes del QUORIDOR

##Equipo: Ratones y mazmorras
##Manuel Tejada García, Francisco Lendinez Tirado, Erik Tordera Bermejo

** En este momento estamos diseñando la visualización del tablero ** 
